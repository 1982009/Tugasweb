let age: number  = 25;
let name: string = "Lidiayanti Silitonga"
let isActive: boolean = true;
let notFound: null = null;
let anything: any = "any value"
anything = 42;

let salary = 5000;
let messege = "Hello world";

function logMessege(): void{
    console.log("Ini adalah fungsi void");
}

export{};